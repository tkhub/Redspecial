#define MKR_JDG_WAIT    20  // ms
#define MKR_MSK_WAIT    10  // ms
#define MKR_WAIT_MAX    200
#define MKR_NON     0
#define MKR_CN      1
#define MKR_GR      2
#define MKR_CRS     3
#define MKR_WNOIS_MASK 3 // 白を?ms検出を続けると検出
#define MKR_BNOIS_MASK 3 // 黒を?ms検出を続けると検出